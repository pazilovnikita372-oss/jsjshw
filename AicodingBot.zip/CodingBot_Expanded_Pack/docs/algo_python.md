### Бинарный поиск (Python) | binary search бинарный поиск sorted array отсортированный массив O(log n) python Python | Python
```python
def binary_search(a, x):
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if a[mid] == x:
            return mid
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1
```

### Быстрая сортировка (Python) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) python Python | Python
```python
def quicksort(a):
    if len(a) <= 1:
        return a
    p = a[len(a) // 2]
    left = [x for x in a if x < p]
    mid = [x for x in a if x == p]
    right = [x for x in a if x > p]
    return quicksort(left) + mid + quicksort(right)
```

### Сортировка слиянием (Python) | merge sort сортировка слиянием sort алгоритм stable стабильная python Python | Python
```python
def merge_sort(a):
    if len(a) <= 1:
        return a
    m = len(a) // 2
    l, r = merge_sort(a[:m]), merge_sort(a[m:])
    out, i, j = [], 0, 0
    while i < len(l) and j < len(r):
        if l[i] <= r[j]:
            out.append(l[i]); i += 1
        else:
            out.append(r[j]); j += 1
    return out + l[i:] + r[j:]
```

### Числа Фибоначчи (Python) | fibonacci фибоначчи число recursion рекурсия итерация python Python | Python
```python
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
```

### Проверка на простое число (Python) | prime простое число is_prime простые sieve решето python Python | Python
```python
def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True
```

### Разворот строки (Python) | reverse string развернуть строку reverse перевернуть python Python | Python
```python
def reverse(s):
    return s[::-1]
```

### Палиндром (Python) | palindrome палиндром проверка строка python Python | Python
```python
def is_palindrome(s):
    t = [c.lower() for c in s if c.isalnum()]
    return t == t[::-1]
```

### Наибольший общий делитель (НОД) (Python) | gcd нод greatest common divisor euclid евклид python Python | Python
```python
import math
math.gcd(48, 18)  # 6

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a
```

### Подсчёт слов в тексте (Python) | count words частота слов word frequency hashmap словарь dictionary python Python | Python
```python
from collections import Counter
import re

def word_freq(text):
    words = re.findall(r"\w+", text.lower())
    return Counter(words).most_common()
```

### Чтение файла построчно (Python) | read file чтение файла построчно file io open python Python | Python
```python
with open("data.txt", encoding="utf-8") as f:
    for line in f:
        print(line.rstrip())
```

### HTTP GET запрос (Python) | http get запрос request fetch api rest json python Python | Python
```python
import requests

r = requests.get("https://api.example.com/items", params={"q": "x"}, timeout=10)
r.raise_for_status()
data = r.json()
```

### Разбор JSON (Python) | json parse разбор json serialize сериализация десериализация python Python | Python
```python
import json
obj = json.loads('{"a": 1, "b": [1, 2]}')
text = json.dumps(obj, ensure_ascii=False, indent=2)
```

### FizzBuzz (Python) | fizzbuzz физзбазз loops циклы условия python Python | Python
```python
for i in range(1, 101):
    print("FizzBuzz" if i % 15 == 0 else "Fizz" if i % 3 == 0 else "Buzz" if i % 5 == 0 else i)
```

### Класс и наследование (Python) | class inheritance класс наследование ооп oop interface интерфейс python Python | Python
```python
class Animal:
    def __init__(self, name):
        self.name = name
    def speak(self):
        raise NotImplementedError

class Dog(Animal):
    def speak(self):
        return f"{self.name}: Гав!"
```

### Обработка ошибок (Python) | error handling exceptions обработка ошибок исключения try catch python Python | Python
```python
try:
    x = int(input())
except ValueError as e:
    print("не число:", e)
else:
    print("ok", x)
finally:
    print("всегда")
```

### Потоки и параллелизм (Python) | thread async parallel потоки асинхронность concurrency корутины coroutine python Python | Python
```python
import asyncio

async def work(i):
    await asyncio.sleep(1)
    return i * 2

async def main():
    print(await asyncio.gather(*(work(i) for i in range(5))))

asyncio.run(main())
```
