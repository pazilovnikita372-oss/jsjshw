### Бинарный поиск (C++) | binary search бинарный поиск sorted array отсортированный массив O(log n) cpp C++ | C++
```cpp
int binarySearch(const std::vector<int>& a, int x) {
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == x) return mid;
        if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}
```

### Быстрая сортировка (C++) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) cpp C++ | C++
```cpp
void quicksort(std::vector<int>& a, int lo, int hi) {
    if (lo >= hi) return;
    int p = a[lo + (hi - lo) / 2], i = lo, j = hi;
    while (i <= j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) std::swap(a[i++], a[j--]);
    }
    quicksort(a, lo, j);
    quicksort(a, i, hi);
}
```

### Сортировка слиянием (C++) | merge sort сортировка слиянием sort алгоритм stable стабильная cpp C++ | C++
```cpp
std::vector<int> mergeSort(std::vector<int> a) {
    if (a.size() <= 1) return a;
    auto mid = a.begin() + a.size() / 2;
    auto l = mergeSort({a.begin(), mid});
    auto r = mergeSort({mid, a.end()});
    std::vector<int> out(a.size());
    std::merge(l.begin(), l.end(), r.begin(), r.end(), out.begin());
    return out;
}
```

### Числа Фибоначчи (C++) | fibonacci фибоначчи число recursion рекурсия итерация cpp C++ | C++
```cpp
unsigned long long fib(int n) {
    unsigned long long a = 0, b = 1;
    for (int i = 0; i < n; i++) { auto t = a + b; a = b; b = t; }
    return a;
}
```

### Проверка на простое число (C++) | prime простое число is_prime простые sieve решето cpp C++ | C++
```cpp
bool isPrime(int n) {
    if (n < 2) return false;
    for (long long i = 2; i * i <= n; i++) if (n % i == 0) return false;
    return true;
}
```

### Разворот строки (C++) | reverse string развернуть строку reverse перевернуть cpp C++ | C++
```cpp
std::string reverse(std::string s) {
    std::reverse(s.begin(), s.end());
    return s;
}
```

### Палиндром (C++) | palindrome палиндром проверка строка cpp C++ | C++
```cpp
bool isPalindrome(const std::string& s) {
    std::string t;
    for (unsigned char c : s) if (std::isalnum(c)) t += std::tolower(c);
    return std::equal(t.begin(), t.begin() + t.size() / 2, t.rbegin());
}
```

### Наибольший общий делитель (НОД) (C++) | gcd нод greatest common divisor euclid евклид cpp C++ | C++
```cpp
#include <numeric>
auto g = std::gcd(48, 18); // C++17

long long gcd(long long a, long long b) { return b ? gcd(b, a % b) : a; }
```

### Подсчёт слов в тексте (C++) | count words частота слов word frequency hashmap словарь dictionary cpp C++ | C++
```cpp
std::map<std::string, int> wordFreq(std::istream& in) {
    std::map<std::string, int> m;
    std::string w;
    while (in >> w) m[w]++;
    return m;
}
```

### Чтение файла построчно (C++) | read file чтение файла построчно file io open cpp C++ | C++
```cpp
std::ifstream f("data.txt");
std::string line;
while (std::getline(f, line)) std::cout << line << '\n';
```

### HTTP GET запрос (C++) | http get запрос request fetch api rest json cpp C++ | C++
```cpp
// libcurl
CURL* c = curl_easy_init();
curl_easy_setopt(c, CURLOPT_URL, "https://api.example.com/items");
curl_easy_perform(c);
curl_easy_cleanup(c);
```

### Разбор JSON (C++) | json parse разбор json serialize сериализация десериализация cpp C++ | C++
```cpp
// nlohmann/json
auto j = nlohmann::json::parse(R"({"a":1,"b":[1,2]})");
std::cout << j.dump(2);
```

### FizzBuzz (C++) | fizzbuzz физзбазз loops циклы условия cpp C++ | C++
```cpp
for (int i = 1; i <= 100; i++) {
    if (i % 15 == 0) std::cout << "FizzBuzz\n";
    else if (i % 3 == 0) std::cout << "Fizz\n";
    else if (i % 5 == 0) std::cout << "Buzz\n";
    else std::cout << i << '\n';
}
```

### Класс и наследование (C++) | class inheritance класс наследование ооп oop interface интерфейс cpp C++ | C++
```cpp
struct Animal {
    std::string name;
    explicit Animal(std::string n) : name(std::move(n)) {}
    virtual std::string speak() const = 0;
    virtual ~Animal() = default;
};
struct Dog : Animal {
    using Animal::Animal;
    std::string speak() const override { return name + ": Woof"; }
};
```

### Обработка ошибок (C++) | error handling exceptions обработка ошибок исключения try catch cpp C++ | C++
```cpp
try {
    int x = std::stoi(text);
} catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
}
```

### Потоки и параллелизм (C++) | thread async parallel потоки асинхронность concurrency корутины coroutine cpp C++ | C++
```cpp
auto f = std::async(std::launch::async, [] { return 21 * 2; });
std::cout << f.get();
```
