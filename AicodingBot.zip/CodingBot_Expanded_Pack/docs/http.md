### HTTP: коды статусов | http status code коды ответа 200 404 500 статус | HTTP
- **200** OK · **201** Created · **204** No Content
- **301** постоянный редирект · **302** временный · **304** Not Modified
- **400** Bad Request (неверный запрос) · **401** Unauthorized (нет/неверная аутентификация) · **403** Forbidden (нет прав) · **404** Not Found · **405** Method Not Allowed · **409** Conflict · **422** Unprocessable Entity · **429** Too Many Requests
- **500** Internal Server Error · **502** Bad Gateway · **503** Service Unavailable · **504** Gateway Timeout

### HTTP: методы | http methods get post put patch delete методы rest | HTTP
- **GET**: получить, без тела, идемпотентен
- **POST**: создать
- **PUT**: заменить целиком, идемпотентен
- **PATCH**: изменить частично
- **DELETE**: удалить, идемпотентен

### REST API: хорошие практики | rest api дизайн практики endpoint ресурсы | HTTP
- Существительные во множественном числе: `/users/42/orders`
- Глагол задаёт метод, а не путь
- Версионирование: `/v1/...`
- Пагинация: `?limit=20&cursor=...`
- Ошибки в едином формате: `{"error":{"code":"...","message":"..."}}`
- Идемпотентность для POST: заголовок `Idempotency-Key`

### CORS | cors cross origin ошибка браузер access-control-allow-origin | HTTP
Ошибка «blocked by CORS policy» значит, что сервер не разрешил запросы с твоего origin. Чинится **на сервере**:
```
Access-Control-Allow-Origin: https://my-site.com
Access-Control-Allow-Methods: GET, POST
Access-Control-Allow-Headers: Content-Type, Authorization
```
Preflight: браузер сначала шлёт `OPTIONS`, на него тоже нужен ответ с этими заголовками.

### JWT и авторизация | jwt token bearer авторизация аутентификация токен | HTTP
- JWT = `header.payload.signature`. Payload **не зашифрован**, секреты туда не клади.
- Всегда проверяй подпись и `exp` на сервере.
- Хранение в браузере: httpOnly cookie безопаснее localStorage (защита от XSS).
- Заголовок: `Authorization: Bearer <token>`.

### HTTPS и порты | порты ports 80 443 22 5432 3306 6379 стандартные порты | HTTP
80 HTTP · 443 HTTPS · 22 SSH · 21 FTP · 25 SMTP · 53 DNS · 3306 MySQL · 5432 PostgreSQL · 6379 Redis · 27017 MongoDB · 8080 типичный dev-порт
