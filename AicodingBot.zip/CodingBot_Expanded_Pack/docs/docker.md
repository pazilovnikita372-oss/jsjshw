### Docker: основные команды | docker команды run ps images контейнер образ | Docker
```bash
docker run -d -p 8080:80 --name web nginx
docker ps -a
docker logs -f web
docker exec -it web sh
docker stop web && docker rm web
docker images
docker rmi nginx
docker system prune -a      # чистка (осторожно)
```

### Docker: Dockerfile | dockerfile docker build образ сборка | Docker
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```
Копируй requirements отдельно: слои кэшируются, пересборка быстрее.

### Docker Compose | docker compose yml сервисы база | Docker
```yaml
services:
  app:
    build: .
    ports: ["8000:8000"]
    environment:
      DATABASE_URL: postgres://user:pass@db:5432/app
    depends_on: [db]
  db:
    image: postgres:16
    environment:
      POSTGRES_PASSWORD: pass
    volumes:
      - dbdata:/var/lib/postgresql/data
volumes:
  dbdata:
```
```bash
docker compose up -d
docker compose logs -f
docker compose down
```

### Docker: volumes и сети | docker volume network том сеть данные | Docker
```bash
docker volume create data
docker run -v data:/var/lib/app myimage
docker network create mynet
docker run --network mynet --name api myimage
```
Контейнеры в одной сети обращаются друг к другу по имени.

### Docker: multi-stage build | docker multi stage многоэтапная маленький образ | Docker
```dockerfile
FROM golang:1.23 AS build
WORKDIR /src
COPY . .
RUN CGO_ENABLED=0 go build -o /app

FROM gcr.io/distroless/static
COPY --from=build /app /app
ENTRYPOINT ["/app"]
```
