### Бинарный поиск: все языки | binary search бинарный поиск sorted array отсортированный массив O(log n) сравнение языков | Сравнение
**Python**
```python
def binary_search(a, x):
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if a[mid] == x:
            return mid
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1
```
**JavaScript**
```javascript
function binarySearch(a, x) {
  let lo = 0, hi = a.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (a[mid] === x) return mid;
    if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}
```
**Kotlin**
```kotlin
fun binarySearch(a: IntArray, x: Int): Int {
    var lo = 0
    var hi = a.size - 1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        when {
            a[mid] == x -> return mid
            a[mid] < x -> lo = mid + 1
            else -> hi = mid - 1
        }
    }
    return -1
}
```
**Java**
```java
static int binarySearch(int[] a, int x) {
    int lo = 0, hi = a.length - 1;
    while (lo <= hi) {
        int mid = (lo + hi) >>> 1;
        if (a[mid] == x) return mid;
        if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}
```

### Быстрая сортировка: все языки | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) сравнение языков | Сравнение
**Python**
```python
def quicksort(a):
    if len(a) <= 1:
        return a
    p = a[len(a) // 2]
    left = [x for x in a if x < p]
    mid = [x for x in a if x == p]
    right = [x for x in a if x > p]
    return quicksort(left) + mid + quicksort(right)
```
**JavaScript**
```javascript
function quicksort(a) {
  if (a.length <= 1) return a;
  const p = a[a.length >> 1];
  return [
    ...quicksort(a.filter(x => x < p)),
    ...a.filter(x => x === p),
    ...quicksort(a.filter(x => x > p)),
  ];
}
```
**Kotlin**
```kotlin
fun quicksort(a: List<Int>): List<Int> {
    if (a.size <= 1) return a
    val p = a[a.size / 2]
    return quicksort(a.filter { it < p }) + a.filter { it == p } + quicksort(a.filter { it > p })
}
```
**Java**
```java
static void quicksort(int[] a, int lo, int hi) {
    if (lo >= hi) return;
    int p = a[(lo + hi) >>> 1], i = lo, j = hi;
    while (i <= j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) { int t = a[i]; a[i] = a[j]; a[j] = t; i++; j--; }
    }
    quicksort(a, lo, j);
    quicksort(a, i, hi);
}
```

### Сортировка слиянием: все языки | merge sort сортировка слиянием sort алгоритм stable стабильная сравнение языков | Сравнение
**Python**
```python
def merge_sort(a):
    if len(a) <= 1:
        return a
    m = len(a) // 2
    l, r = merge_sort(a[:m]), merge_sort(a[m:])
    out, i, j = [], 0, 0
    while i < len(l) and j < len(r):
        if l[i] <= r[j]:
            out.append(l[i]); i += 1
        else:
            out.append(r[j]); j += 1
    return out + l[i:] + r[j:]
```
**JavaScript**
```javascript
function mergeSort(a) {
  if (a.length <= 1) return a;
  const m = a.length >> 1;
  const l = mergeSort(a.slice(0, m)), r = mergeSort(a.slice(m));
  const out = [];
  let i = 0, j = 0;
  while (i < l.length && j < r.length) out.push(l[i] <= r[j] ? l[i++] : r[j++]);
  return out.concat(l.slice(i), r.slice(j));
}
```
**Kotlin**
```kotlin
fun mergeSort(a: List<Int>): List<Int> {
    if (a.size <= 1) return a
    val m = a.size / 2
    val l = mergeSort(a.subList(0, m))
    val r = mergeSort(a.subList(m, a.size))
    val out = ArrayList<Int>(a.size)
    var i = 0; var j = 0
    while (i < l.size && j < r.size) out.add(if (l[i] <= r[j]) l[i++] else r[j++])
    while (i < l.size) out.add(l[i++])
    while (j < r.size) out.add(r[j++])
    return out
}
```
**Java**
```java
static int[] mergeSort(int[] a) {
    if (a.length <= 1) return a;
    int m = a.length / 2;
    int[] l = mergeSort(Arrays.copyOfRange(a, 0, m));
    int[] r = mergeSort(Arrays.copyOfRange(a, m, a.length));
    int[] out = new int[a.length];
    int i = 0, j = 0, k = 0;
    while (i < l.length && j < r.length) out[k++] = l[i] <= r[j] ? l[i++] : r[j++];
    while (i < l.length) out[k++] = l[i++];
    while (j < r.length) out[k++] = r[j++];
    return out;
}
```

### Числа Фибоначчи: все языки | fibonacci фибоначчи число recursion рекурсия итерация сравнение языков | Сравнение
**Python**
```python
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
```
**JavaScript**
```javascript
function fib(n) {
  let a = 0n, b = 1n;
  for (let i = 0; i < n; i++) [a, b] = [b, a + b];
  return a; // BigInt, не переполняется
}
```
**Kotlin**
```kotlin
fun fib(n: Int): Long {
    var a = 0L; var b = 1L
    repeat(n) { val t = a + b; a = b; b = t }
    return a
}
```
**Java**
```java
static long fib(int n) {
    long a = 0, b = 1;
    for (int i = 0; i < n; i++) { long t = a + b; a = b; b = t; }
    return a;
}
```

### Проверка на простое число: все языки | prime простое число is_prime простые sieve решето сравнение языков | Сравнение
**Python**
```python
def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True
```
**JavaScript**
```javascript
function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
  return true;
}
```
**Kotlin**
```kotlin
fun isPrime(n: Int): Boolean {
    if (n < 2) return false
    var i = 2
    while (i.toLong() * i <= n) { if (n % i == 0) return false; i++ }
    return true
}
```
**Java**
```java
static boolean isPrime(int n) {
    if (n < 2) return false;
    for (long i = 2; i * i <= n; i++) if (n % i == 0) return false;
    return true;
}
```

### Разворот строки: все языки | reverse string развернуть строку reverse перевернуть сравнение языков | Сравнение
**Python**
```python
def reverse(s):
    return s[::-1]
```
**JavaScript**
```javascript
const reverse = s => [...s].reverse().join('');
```
**Kotlin**
```kotlin
fun reverse(s: String) = s.reversed()
```
**Java**
```java
static String reverse(String s) {
    return new StringBuilder(s).reverse().toString();
}
```

### Палиндром: все языки | palindrome палиндром проверка строка сравнение языков | Сравнение
**Python**
```python
def is_palindrome(s):
    t = [c.lower() for c in s if c.isalnum()]
    return t == t[::-1]
```
**JavaScript**
```javascript
const isPalindrome = s => {
  const t = s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
  return t === [...t].reverse().join('');
};
```
**Kotlin**
```kotlin
fun isPalindrome(s: String): Boolean {
    val t = s.filter { it.isLetterOrDigit() }.lowercase()
    return t == t.reversed()
}
```
**Java**
```java
static boolean isPalindrome(String s) {
    String t = s.replaceAll("[^\\p{L}\\p{N}]", "").toLowerCase();
    return t.equals(new StringBuilder(t).reverse().toString());
}
```

### Наибольший общий делитель (НОД): все языки | gcd нод greatest common divisor euclid евклид сравнение языков | Сравнение
**Python**
```python
import math
math.gcd(48, 18)  # 6

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a
```
**JavaScript**
```javascript
const gcd = (a, b) => (b === 0 ? a : gcd(b, a % b));
```
**Kotlin**
```kotlin
tailrec fun gcd(a: Long, b: Long): Long = if (b == 0L) a else gcd(b, a % b)
```
**Java**
```java
static long gcd(long a, long b) {
    return b == 0 ? a : gcd(b, a % b);
}
```

### Подсчёт слов в тексте: все языки | count words частота слов word frequency hashmap словарь dictionary сравнение языков | Сравнение
**Python**
```python
from collections import Counter
import re

def word_freq(text):
    words = re.findall(r"\w+", text.lower())
    return Counter(words).most_common()
```
**JavaScript**
```javascript
function wordFreq(text) {
  const m = new Map();
  for (const w of text.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [])
    m.set(w, (m.get(w) ?? 0) + 1);
  return [...m].sort((a, b) => b[1] - a[1]);
}
```
**Kotlin**
```kotlin
fun wordFreq(text: String) =
    Regex("[\\p{L}\\p{N}]+").findAll(text.lowercase())
        .map { it.value }
        .groupingBy { it }.eachCount()
        .toList().sortedByDescending { it.second }
```
**Java**
```java
static Map<String, Long> wordFreq(String text) {
    return Arrays.stream(text.toLowerCase().split("[^\\p{L}\\p{N}]+"))
        .filter(w -> !w.isEmpty())
        .collect(Collectors.groupingBy(w -> w, Collectors.counting()));
}
```

### Чтение файла построчно: все языки | read file чтение файла построчно file io open сравнение языков | Сравнение
**Python**
```python
with open("data.txt", encoding="utf-8") as f:
    for line in f:
        print(line.rstrip())
```
**JavaScript**
```javascript
// Node.js
import { createReadStream } from 'node:fs';
import readline from 'node:readline';

const rl = readline.createInterface({ input: createReadStream('data.txt') });
for await (const line of rl) console.log(line);
```
**Kotlin**
```kotlin
java.io.File("data.txt").forEachLine { println(it) }
```
**Java**
```java
try (var lines = Files.lines(Path.of("data.txt"))) {
    lines.forEach(System.out::println);
}
```

### HTTP GET запрос: все языки | http get запрос request fetch api rest json сравнение языков | Сравнение
**Python**
```python
import requests

r = requests.get("https://api.example.com/items", params={"q": "x"}, timeout=10)
r.raise_for_status()
data = r.json()
```
**JavaScript**
```javascript
const res = await fetch('https://api.example.com/items?q=x');
if (!res.ok) throw new Error(res.status);
const data = await res.json();
```
**Kotlin**
```kotlin
// Без библиотек
val c = URL("https://api.example.com/items").openConnection() as HttpURLConnection
val text = c.inputStream.bufferedReader().readText()
// Запускать НЕ в главном потоке: withContext(Dispatchers.IO) { ... }
```
**Java**
```java
var client = HttpClient.newHttpClient();
var req = HttpRequest.newBuilder(URI.create("https://api.example.com/items")).build();
var res = client.send(req, HttpResponse.BodyHandlers.ofString());
System.out.println(res.body());
```

### Разбор JSON: все языки | json parse разбор json serialize сериализация десериализация сравнение языков | Сравнение
**Python**
```python
import json
obj = json.loads('{"a": 1, "b": [1, 2]}')
text = json.dumps(obj, ensure_ascii=False, indent=2)
```
**JavaScript**
```javascript
const obj = JSON.parse('{"a":1,"b":[1,2]}');
const text = JSON.stringify(obj, null, 2);
```
**Kotlin**
```kotlin
// kotlinx.serialization
@Serializable data class Item(val a: Int, val b: List<Int>)
val item = Json.decodeFromString<Item>("""{"a":1,"b":[1,2]}""")
val text = Json.encodeToString(item)
```
**Java**
```java
// Jackson
var mapper = new ObjectMapper();
Item item = mapper.readValue(json, Item.class);
String text = mapper.writeValueAsString(item);
```

### FizzBuzz: все языки | fizzbuzz физзбазз loops циклы условия сравнение языков | Сравнение
**Python**
```python
for i in range(1, 101):
    print("FizzBuzz" if i % 15 == 0 else "Fizz" if i % 3 == 0 else "Buzz" if i % 5 == 0 else i)
```
**JavaScript**
```javascript
for (let i = 1; i <= 100; i++)
  console.log(i % 15 === 0 ? 'FizzBuzz' : i % 3 === 0 ? 'Fizz' : i % 5 === 0 ? 'Buzz' : i);
```
**Kotlin**
```kotlin
for (i in 1..100) println(when {
    i % 15 == 0 -> "FizzBuzz"
    i % 3 == 0 -> "Fizz"
    i % 5 == 0 -> "Buzz"
    else -> i
})
```
**Java**
```java
for (int i = 1; i <= 100; i++)
    System.out.println(i % 15 == 0 ? "FizzBuzz" : i % 3 == 0 ? "Fizz" : i % 5 == 0 ? "Buzz" : String.valueOf(i));
```

### Класс и наследование: все языки | class inheritance класс наследование ооп oop interface интерфейс сравнение языков | Сравнение
**Python**
```python
class Animal:
    def __init__(self, name):
        self.name = name
    def speak(self):
        raise NotImplementedError

class Dog(Animal):
    def speak(self):
        return f"{self.name}: Гав!"
```
**JavaScript**
```javascript
class Animal {
  constructor(name) { this.name = name; }
  speak() { throw new Error('not implemented'); }
}
class Dog extends Animal {
  speak() { return `${this.name}: Гав!`; }
}
```
**Kotlin**
```kotlin
abstract class Animal(val name: String) {
    abstract fun speak(): String
}
class Dog(name: String) : Animal(name) {
    override fun speak() = "$name: Гав!"
}
```
**Java**
```java
abstract class Animal {
    protected final String name;
    Animal(String name) { this.name = name; }
    abstract String speak();
}
class Dog extends Animal {
    Dog(String n) { super(n); }
    String speak() { return name + ": Гав!"; }
}
```

### Обработка ошибок: все языки | error handling exceptions обработка ошибок исключения try catch сравнение языков | Сравнение
**Python**
```python
try:
    x = int(input())
except ValueError as e:
    print("не число:", e)
else:
    print("ok", x)
finally:
    print("всегда")
```
**JavaScript**
```javascript
try {
  JSON.parse(text);
} catch (e) {
  console.error('ошибка:', e.message);
} finally {
  console.log('всегда');
}
```
**Kotlin**
```kotlin
val n = runCatching { text.toInt() }.getOrElse { 0 }

try { risky() }
catch (e: IllegalStateException) { println(e.message) }
finally { println("всегда") }
```
**Java**
```java
try {
    Integer.parseInt(text);
} catch (NumberFormatException e) {
    System.err.println(e.getMessage());
} finally {
    System.out.println("всегда");
}
```

### Потоки и параллелизм: все языки | thread async parallel потоки асинхронность concurrency корутины coroutine сравнение языков | Сравнение
**Python**
```python
import asyncio

async def work(i):
    await asyncio.sleep(1)
    return i * 2

async def main():
    print(await asyncio.gather(*(work(i) for i in range(5))))

asyncio.run(main())
```
**JavaScript**
```javascript
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = await Promise.all([1, 2, 3].map(async i => { await sleep(100); return i * 2; }));
```
**Kotlin**
```kotlin
runBlocking {
    val r = (1..5).map { i -> async { delay(1000); i * 2 } }.awaitAll()
    println(r)
}
```
**Java**
```java
try (var ex = Executors.newFixedThreadPool(4)) {
    var f = ex.submit(() -> 21 * 2);
    System.out.println(f.get());
}
```
