### Бинарный поиск (Java) | binary search бинарный поиск sorted array отсортированный массив O(log n) java Java | Java
```java
static int binarySearch(int[] a, int x) {
    int lo = 0, hi = a.length - 1;
    while (lo <= hi) {
        int mid = (lo + hi) >>> 1;
        if (a[mid] == x) return mid;
        if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}
```

### Быстрая сортировка (Java) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) java Java | Java
```java
static void quicksort(int[] a, int lo, int hi) {
    if (lo >= hi) return;
    int p = a[(lo + hi) >>> 1], i = lo, j = hi;
    while (i <= j) {
        while (a[i] < p) i++;
        while (a[j] > p) j--;
        if (i <= j) { int t = a[i]; a[i] = a[j]; a[j] = t; i++; j--; }
    }
    quicksort(a, lo, j);
    quicksort(a, i, hi);
}
```

### Сортировка слиянием (Java) | merge sort сортировка слиянием sort алгоритм stable стабильная java Java | Java
```java
static int[] mergeSort(int[] a) {
    if (a.length <= 1) return a;
    int m = a.length / 2;
    int[] l = mergeSort(Arrays.copyOfRange(a, 0, m));
    int[] r = mergeSort(Arrays.copyOfRange(a, m, a.length));
    int[] out = new int[a.length];
    int i = 0, j = 0, k = 0;
    while (i < l.length && j < r.length) out[k++] = l[i] <= r[j] ? l[i++] : r[j++];
    while (i < l.length) out[k++] = l[i++];
    while (j < r.length) out[k++] = r[j++];
    return out;
}
```

### Числа Фибоначчи (Java) | fibonacci фибоначчи число recursion рекурсия итерация java Java | Java
```java
static long fib(int n) {
    long a = 0, b = 1;
    for (int i = 0; i < n; i++) { long t = a + b; a = b; b = t; }
    return a;
}
```

### Проверка на простое число (Java) | prime простое число is_prime простые sieve решето java Java | Java
```java
static boolean isPrime(int n) {
    if (n < 2) return false;
    for (long i = 2; i * i <= n; i++) if (n % i == 0) return false;
    return true;
}
```

### Разворот строки (Java) | reverse string развернуть строку reverse перевернуть java Java | Java
```java
static String reverse(String s) {
    return new StringBuilder(s).reverse().toString();
}
```

### Палиндром (Java) | palindrome палиндром проверка строка java Java | Java
```java
static boolean isPalindrome(String s) {
    String t = s.replaceAll("[^\\p{L}\\p{N}]", "").toLowerCase();
    return t.equals(new StringBuilder(t).reverse().toString());
}
```

### Наибольший общий делитель (НОД) (Java) | gcd нод greatest common divisor euclid евклид java Java | Java
```java
static long gcd(long a, long b) {
    return b == 0 ? a : gcd(b, a % b);
}
```

### Подсчёт слов в тексте (Java) | count words частота слов word frequency hashmap словарь dictionary java Java | Java
```java
static Map<String, Long> wordFreq(String text) {
    return Arrays.stream(text.toLowerCase().split("[^\\p{L}\\p{N}]+"))
        .filter(w -> !w.isEmpty())
        .collect(Collectors.groupingBy(w -> w, Collectors.counting()));
}
```

### Чтение файла построчно (Java) | read file чтение файла построчно file io open java Java | Java
```java
try (var lines = Files.lines(Path.of("data.txt"))) {
    lines.forEach(System.out::println);
}
```

### HTTP GET запрос (Java) | http get запрос request fetch api rest json java Java | Java
```java
var client = HttpClient.newHttpClient();
var req = HttpRequest.newBuilder(URI.create("https://api.example.com/items")).build();
var res = client.send(req, HttpResponse.BodyHandlers.ofString());
System.out.println(res.body());
```

### Разбор JSON (Java) | json parse разбор json serialize сериализация десериализация java Java | Java
```java
// Jackson
var mapper = new ObjectMapper();
Item item = mapper.readValue(json, Item.class);
String text = mapper.writeValueAsString(item);
```

### FizzBuzz (Java) | fizzbuzz физзбазз loops циклы условия java Java | Java
```java
for (int i = 1; i <= 100; i++)
    System.out.println(i % 15 == 0 ? "FizzBuzz" : i % 3 == 0 ? "Fizz" : i % 5 == 0 ? "Buzz" : String.valueOf(i));
```

### Класс и наследование (Java) | class inheritance класс наследование ооп oop interface интерфейс java Java | Java
```java
abstract class Animal {
    protected final String name;
    Animal(String name) { this.name = name; }
    abstract String speak();
}
class Dog extends Animal {
    Dog(String n) { super(n); }
    String speak() { return name + ": Гав!"; }
}
```

### Обработка ошибок (Java) | error handling exceptions обработка ошибок исключения try catch java Java | Java
```java
try {
    Integer.parseInt(text);
} catch (NumberFormatException e) {
    System.err.println(e.getMessage());
} finally {
    System.out.println("всегда");
}
```

### Потоки и параллелизм (Java) | thread async parallel потоки асинхронность concurrency корутины coroutine java Java | Java
```java
try (var ex = Executors.newFixedThreadPool(4)) {
    var f = ex.submit(() -> 21 * 2);
    System.out.println(f.get());
}
```
