### Python: списки и comprehensions | python list comprehension список генератор comprehensions | Python
```python
squares = [x * x for x in range(10) if x % 2 == 0]
d = {k: v for k, v in pairs}
s = {x % 3 for x in nums}
g = (x * x for x in range(10**6))     # генератор, не хранит всё
```

### Python: словари | python dict словарь get items setdefault defaultdict | Python
```python
from collections import defaultdict, Counter
d = {"a": 1}
d.get("b", 0)
for k, v in d.items(): ...
groups = defaultdict(list); groups["x"].append(1)
Counter("hello").most_common(2)
merged = d | {"c": 3}
```

### Python: сортировка | python sort sorted key lambda сортировка по ключу | Python
```python
people.sort(key=lambda p: (p["age"], p["name"]))
sorted(words, key=len, reverse=True)
from operator import itemgetter
sorted(rows, key=itemgetter(1))
```

### Python: файлы и pathlib | python pathlib файлы чтение запись path open | Python
```python
from pathlib import Path
p = Path("data") / "a.txt"
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text("привет", encoding="utf-8")
text = p.read_text(encoding="utf-8")
for f in Path(".").rglob("*.py"): print(f)
```

### Python: dataclass | python dataclass класс данные dataclasses | Python
```python
from dataclasses import dataclass, field

@dataclass(frozen=True)
class Point:
    x: float
    y: float = 0.0
    tags: list[str] = field(default_factory=list)
```

### Python: декораторы | python decorator декоратор functools wraps | Python
```python
import functools, time

def timed(fn):
    @functools.wraps(fn)
    def wrapper(*a, **kw):
        t = time.perf_counter()
        try:
            return fn(*a, **kw)
        finally:
            print(fn.__name__, time.perf_counter() - t)
    return wrapper
```

### Python: контекстные менеджеры | python with context manager контекстный менеджер | Python
```python
from contextlib import contextmanager

@contextmanager
def cd(path):
    import os
    old = os.getcwd(); os.chdir(path)
    try: yield
    finally: os.chdir(old)
```

### Python: виртуальное окружение | python venv virtualenv pip requirements окружение | Python
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip freeze > requirements.txt
```

### Python: Flask мини-API | python flask api сервер веб web | Python
```python
from flask import Flask, jsonify, request
app = Flask(__name__)

@app.get("/hello")
def hello():
    return jsonify(msg="привет", name=request.args.get("name"))

if __name__ == "__main__":
    app.run(debug=True)
```

### Python: FastAPI | python fastapi api pydantic async сервер | Python
```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Item(BaseModel):
    name: str
    price: float

@app.post("/items")
def create(item: Item):
    return {"ok": True, "item": item}
# uvicorn main:app --reload
```

### Python: pandas основы | python pandas dataframe csv данные таблица анализ | Python
```python
import pandas as pd
df = pd.read_csv("data.csv")
df.head(); df.info(); df.describe()
df[df["age"] > 30].groupby("city")["salary"].mean()
df["new"] = df["a"] + df["b"]
df.to_csv("out.csv", index=False)
```

### Python: Telegram-бот | python telegram bot бот aiogram | Python
```python
# pip install aiogram
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message

dp = Dispatcher()

@dp.message(Command("start"))
async def start(m: Message):
    await m.answer("Привет!")

async def main():
    await dp.start_polling(Bot(token="TOKEN"))

asyncio.run(main())
```
Токен получи у @BotFather и не публикуй его.

### Python: типы | python typing type hints аннотации типов mypy | Python
```python
from typing import Optional, Callable
def f(x: int, y: str | None = None) -> list[int]: ...
Handler = Callable[[str], bool]
```

### Python: тесты pytest | python pytest тесты unit test тестирование | Python
```python
# test_calc.py
import pytest
from calc import div

def test_div():
    assert div(6, 3) == 2

def test_zero():
    with pytest.raises(ZeroDivisionError):
        div(1, 0)

@pytest.mark.parametrize("a,b,r", [(4, 2, 2), (9, 3, 3)])
def test_many(a, b, r):
    assert div(a, b) == r
```
Запуск: `pytest -q`.
