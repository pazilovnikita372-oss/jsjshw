package com.example.codingbot

import android.content.Context
import android.database.sqlite.SQLiteDatabase

/**
 * Пример поиска по базе, скопированной в filesDir/databases/python.db.
 * Перед использованием скопируйте базу из assets и обработайте ошибки.
 */
class KnowledgeSearch(private val context: Context) {
    fun search(databaseName: String, query: String, limit: Int = 8): List<String> {
        require(databaseName.matches(Regex("[A-Za-z0-9_]+\\.db")))
        val dbFile = context.getDatabasePath(databaseName)
        if (!dbFile.exists()) return emptyList()

        val safeLimit = limit.coerceIn(1, 30)
        return SQLiteDatabase.openDatabase(
            dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY
        ).use { db ->
            val result = mutableListOf<String>()
            // FTS-запрос: токены экранируются как фразы, чтобы пользовательский ввод
            // не превратился в синтаксис FTS.
            val tokens = query.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(12)
            if (tokens.isEmpty()) return@use emptyList()
            val ftsQuery = tokens.joinToString(" AND ") { "\"${it.replace("\"", "\"\"")}\"" }
            db.rawQuery(
                "SELECT title, body, code FROM knowledge_fts WHERE knowledge_fts MATCH ? LIMIT ?",
                arrayOf(ftsQuery, safeLimit.toString())
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    result += buildString {
                        append(cursor.getString(0)).append("\n")
                        append(cursor.getString(1)).append("\n")
                        append(cursor.getString(2))
                    }
                }
            }
            result
        }
    }
}
